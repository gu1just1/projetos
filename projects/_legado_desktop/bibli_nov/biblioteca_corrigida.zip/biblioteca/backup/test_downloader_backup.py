from pathlib import Path

from download.downloader import (
    detectar_tipo,
    sanitizar_nome_arquivo,
    _formatar_velocidade,
    _formatar_eta,
    _nome_disponivel,
    DownloadItem,
)


def test_detectar_tipo():

    assert detectar_tipo(
        "https://youtube.com/watch?v=123"
    ) == "YouTube"

    assert detectar_tipo(
        "https://site.com/video.mp4"
    ) == "Download direto"


def test_sanitizar_nome_windows():

    nome = sanitizar_nome_arquivo(
        "CON.mp4"
    )

    assert nome != "CON.mp4"
    assert nome.startswith("_")


def test_sanitizar_caracteres_invalidos():

    nome = sanitizar_nome_arquivo(
        'meu:arquivo?.mp4'
    )

    assert ":" not in nome
    assert "?" not in nome


def test_formatadores():

    assert _formatar_velocidade(None) == "-"

    assert _formatar_eta(None) == "-"

    assert "MB/s" in _formatar_velocidade(
        1024 * 1024
    )


def test_nome_disponivel(tmp_path):

    arquivo = tmp_path / "teste.mp4"

    arquivo.write_text(
        "teste",
        encoding="utf-8"
    )

    novo = _nome_disponivel(
        tmp_path,
        "teste.mp4"
    )

    assert novo.name != "teste.mp4"


def test_download_item():

    item = DownloadItem(
        url="https://site.com/video.mp4",
        formato="video",
    )

    assert item.url.startswith(
        "https://"
    )

    assert item.formato == "video"