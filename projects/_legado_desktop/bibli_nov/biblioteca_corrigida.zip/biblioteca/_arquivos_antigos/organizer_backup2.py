"""
utils/organizer.py
===================

Sistema seguro de organização de arquivos do MediaVault.

Responsável por:
- classificar arquivos por extensão
- bloquear extensões perigosas
- sanitizar nomes
- impedir path traversal
- evitar sobrescrita
- copiar arquivos mantendo integridade
"""

import shutil
import re
from pathlib import Path


MAPA_CATEGORIAS = {
    "Videos": {".mp4", ".mkv", ".avi", ".mov", ".webm"},
    "Musicas": {".mp3", ".wav", ".flac", ".m4a", ".ogg"},
    "Fotos": {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"},
    "Documentos": {".pdf", ".docx", ".doc", ".txt", ".pptx", ".xlsx"},
}


EXTENSOES_BLOQUEADAS = {
    ".exe",
    ".bat",
    ".cmd",
    ".ps1",
    ".vbs",
    ".scr",
    ".msi",
    ".com",
    ".js"
}


NOMES_RESERVADOS_WINDOWS = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    "COM1",
    "COM2",
    "COM3",
    "COM4",
    "LPT1",
    "LPT2",
    "LPT3"
}


TAMANHO_MAX_MB_PADRAO = 4096


def nome_seguro(nome: str) -> str:
    """
    Remove elementos perigosos de nomes externos.
    """

    if not nome:
        return "arquivo"


    nome = str(nome)


    # remove caminhos
    nome = nome.replace("\\", "_")
    nome = nome.replace("/", "_")


    # remove traversal
    nome = nome.replace("..", "")


    # remove caracteres perigosos
    nome = re.sub(
        r'[<>:"/\\|?*\x00-\x1f]',
        "_",
        nome
    )


    nome = nome.strip()


    # remove pontos e espaços finais
    nome = nome.rstrip(". ")


    if not nome:
        nome = "arquivo"


    nome_base = Path(nome).stem.upper()


    if nome_base in NOMES_RESERVADOS_WINDOWS:
        nome = "_" + nome


    return nome



def categoria_por_extensao(caminho) -> str:

    ext = Path(caminho).suffix.lower()

    for categoria, extensoes in MAPA_CATEGORIAS.items():

        if ext in extensoes:
            return categoria


    return "Outros"



def extensao_bloqueada(caminho) -> bool:

    return Path(caminho).suffix.lower() in EXTENSOES_BLOQUEADAS



def nome_sem_conflito(destino: Path) -> Path:

    if not destino.exists():
        return destino


    base = destino.stem
    ext = destino.suffix

    contador = 1


    while True:

        novo = destino.with_name(
            f"{base}_{contador}{ext}"
        )


        if not novo.exists():
            return novo


        contador += 1



def organizar_e_copiar(
        origem: Path,
        destino_base: Path,
        usuario: str = "local"
):


    origem = Path(origem)
    destino_base = Path(destino_base)


    if not origem.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {origem}"
        )


    if extensao_bloqueada(origem):
        raise ValueError(
            f"Extensão bloqueada: {origem.suffix}"
        )


    usuario_seguro = nome_seguro(usuario)


    arquivo_seguro = nome_seguro(
        origem.name
    )


    categoria = categoria_por_extensao(
        origem
    )


    pasta_destino = (
        destino_base
        /
        usuario_seguro
        /
        categoria
    )


    pasta_destino.mkdir(
        parents=True,
        exist_ok=True
    )


    destino_final = nome_sem_conflito(
        pasta_destino / arquivo_seguro
    )


    shutil.copy2(
        origem,
        destino_final
    )


    return destino_final