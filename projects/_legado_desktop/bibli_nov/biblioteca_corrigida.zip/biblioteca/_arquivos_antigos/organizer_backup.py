"""
utils/organizer.py
===================
Decide em qual categoria (pasta) um arquivo baixado deve entrar,
baseado na extensão. Usado tanto para organizar a biblioteca local
quanto a estrutura de pastas dentro do pendrive.
"""

import shutil
from pathlib import Path

MAPA_CATEGORIAS = {
    "Videos": {".mp4", ".mkv", ".avi", ".mov", ".webm"},
    "Musicas": {".mp3", ".wav", ".flac", ".m4a", ".ogg"},
    "Fotos": {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"},
    "Documentos": {".pdf", ".docx", ".doc", ".txt", ".pptx", ".xlsx"},
}

# Extensões que nunca devem ser copiadas para o pendrive, por segurança.
EXTENSOES_BLOQUEADAS = {".exe", ".bat", ".cmd", ".ps1", ".vbs", ".scr", ".msi", ".com", ".js"}

TAMANHO_MAX_MB_PADRAO = 4096  # 4 GB por arquivo, ajustável na interface/config


def categoria_por_extensao(caminho) -> str:
    """Retorna o nome da categoria (pasta) correspondente à extensão do
    arquivo, ou 'Outros' se não reconhecida."""
    ext = Path(caminho).suffix.lower()
    for categoria, extensoes in MAPA_CATEGORIAS.items():
        if ext in extensoes:
            return categoria
    return "Outros"


def extensao_bloqueada(caminho) -> bool:
    return Path(caminho).suffix.lower() in EXTENSOES_BLOQUEADAS


def nome_sem_conflito(destino: Path) -> Path:
    """Se já existe um arquivo com esse nome no destino, adiciona um
    sufixo numérico para não sobrescrever nada."""
    if not destino.exists():
        return destino
    base, ext = destino.stem, destino.suffix
    i = 1
    while True:
        candidato = destino.with_name(f"{base}_{i}{ext}")
        if not candidato.exists():
            return candidato
        i += 1


def organizar_e_copiar(origem: Path, destino_base: Path, usuario: str = "local") -> Path:
    """Copia `origem` para dentro de `destino_base`, organizando em
    subpastas por usuário e por categoria (Videos/Musicas/Fotos/...).

    Usado pela interface (gui/interface.py) para o worker de
    armazenamento em segundo plano, após um download ser concluído.

    Lança FileNotFoundError se a origem não existir e OSError se a
    cópia falhar. Retorna o Path final do arquivo copiado.
    """
    origem = Path(origem)
    destino_base = Path(destino_base)

    if not origem.exists():
        raise FileNotFoundError(f"Arquivo de origem não encontrado: {origem}")

    if extensao_bloqueada(origem):
        raise ValueError(f"Tipo de arquivo bloqueado por segurança: {origem.suffix}")

    categoria = categoria_por_extensao(origem)
    usuario_seguro = (usuario or "local").strip() or "local"

    pasta_destino = destino_base / usuario_seguro / categoria
    pasta_destino.mkdir(parents=True, exist_ok=True)

    destino_final = nome_sem_conflito(pasta_destino / origem.name)
    shutil.copy2(origem, destino_final)

    return destino_final
