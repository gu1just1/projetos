"""
utils/organizer.py

Sistema seguro de organização de arquivos MediaVault.

Responsável por:
- Classificação por extensão
- Proteção contra path traversal
- Sanitização de nomes
- Bloqueio de extensões perigosas
- Cópia segura sem sobrescrever arquivos
"""

import shutil
import re
from pathlib import Path


MAPA_CATEGORIAS = {
    "Videos": {
        ".mp4", ".mkv", ".avi", ".mov", ".webm"
    },

    "Musicas": {
        ".mp3", ".wav", ".flac", ".m4a", ".ogg"
    },

    "Fotos": {
        ".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"
    },

    "Documentos": {
        ".pdf", ".docx", ".doc", ".txt",
        ".pptx", ".xlsx"
    },
}


EXTENSOES_BLOQUEADAS = {
    ".exe",
    ".bat",
    ".cmd",
    ".ps1",
    ".vbs",
    ".scr",
    ".msi",
    ".com",
    ".js"
}


NOMES_RESERVADOS_WINDOWS = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    "COM1",
    "COM2",
    "COM3",
    "COM4",
    "LPT1",
    "LPT2"
}


TAMANHO_MAX_MB_PADRAO = 4096



def categoria_por_extensao(caminho):

    ext = Path(caminho).suffix.lower()

    for categoria, extensoes in MAPA_CATEGORIAS.items():

        if ext in extensoes:
            return categoria

    return "Outros"



def extensao_bloqueada(caminho):

    return Path(caminho).suffix.lower() in EXTENSOES_BLOQUEADAS



def nome_seguro(nome):
    """
    Sanitiza nomes de usuário/pastas.

    Rejeita tentativas de manipulação de caminho.
    """

    if not nome:
        return "local"


    nome = str(nome)


    # Bloqueia tentativa de path traversal
    if (
        ".." in nome
        or "/" in nome
        or "\\" in nome
        or ":" in nome
    ):
        return "local"


    # Remove caracteres inválidos
    nome = re.sub(
        r"[^a-zA-Z0-9_-]",
        "_",
        nome
    )


    nome = nome.strip("_")


    if not nome:
        return "local"


    if nome.upper() in NOMES_RESERVADOS_WINDOWS:
        return "local"


    return nome[:50]


def nome_sem_conflito(destino):

    if not destino.exists():
        return destino


    base = destino.stem
    ext = destino.suffix

    contador = 1


    while True:

        novo = destino.with_name(
            f"{base}_{contador}{ext}"
        )

        if not novo.exists():
            return novo

        contador += 1



def organizar_e_copiar(
        origem: Path,
        destino_base: Path,
        usuario="local"
):

    origem = Path(origem)
    destino_base = Path(destino_base)


    if not origem.exists():

        raise FileNotFoundError(
            f"Arquivo não encontrado: {origem}"
        )


    if extensao_bloqueada(origem):

        raise ValueError(
            "Arquivo bloqueado por segurança"
        )


    categoria = categoria_por_extensao(origem)


    usuario_seguro = nome_seguro(usuario)


    pasta_destino = (
        destino_base /
        usuario_seguro /
        categoria
    )


    pasta_destino.mkdir(
        parents=True,
        exist_ok=True
    )


    arquivo_destino = nome_sem_conflito(
        pasta_destino / origem.name
    )


    shutil.copy2(
        origem,
        arquivo_destino
    )


    return arquivo_destino