"""
utils/organizer.py

Sistema seguro de organização e cópia de arquivos
MediaVault
"""

import re
import shutil
from pathlib import Path


MAPA_CATEGORIAS = {
    "Videos": {".mp4", ".mkv", ".avi", ".mov", ".webm"},
    "Musicas": {".mp3", ".wav", ".flac", ".m4a", ".ogg"},
    "Fotos": {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"},
    "Documentos": {
        ".pdf",
        ".docx",
        ".doc",
        ".txt",
        ".pptx",
        ".xlsx"
    },
}


EXTENSOES_BLOQUEADAS = {
    ".exe",
    ".bat",
    ".cmd",
    ".ps1",
    ".vbs",
    ".scr",
    ".msi",
    ".com",
    ".js"
}


NOMES_RESERVADOS_WINDOWS = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


TAMANHO_MAX_MB_PADRAO = 4096


def categoria_por_extensao(caminho):

    extensao = Path(caminho).suffix.lower()

    for categoria, extensoes in MAPA_CATEGORIAS.items():

        if extensao in extensoes:
            return categoria

    return "Outros"



def extensao_bloqueada(caminho):

    return Path(caminho).suffix.lower() in EXTENSOES_BLOQUEADAS



def nome_arquivo_seguro(nome):

    nome = str(nome)

    caminho = Path(nome)

    base = caminho.stem
    extensao = caminho.suffix.lower()


    base = re.sub(
        r'[<>:"/\\|?*\x00-\x1F]',
        "_",
        base
    )


    base = base.strip(" .")


    if not base:
        base = "arquivo"


    if base.upper() in NOMES_RESERVADOS_WINDOWS:
        base = "arquivo_" + base


    base = base[:100]


    return base + extensao



def nome_usuario_seguro(usuario):

    if not usuario:
        return "local"


    usuario = re.sub(
        r'[^a-zA-Z0-9_-]',
        "_",
        usuario
    )


    usuario = usuario.strip("_")


    if not usuario:
        return "local"


    return usuario[:50]



def nome_sem_conflito(destino):

    if not destino.exists():
        return destino


    base = destino.stem
    ext = destino.suffix

    contador = 1


    while True:

        novo = destino.with_name(
            f"{base}_{contador}{ext}"
        )

        if not novo.exists():
            return novo

        contador += 1



def organizar_e_copiar(
        origem: Path,
        destino_base: Path,
        usuario="local"
):

    origem = Path(origem)

    destino_base = Path(destino_base)


    if not origem.exists():

        raise FileNotFoundError(
            f"Arquivo não encontrado: {origem}"
        )


    if extensao_bloqueada(origem):

        raise ValueError(
            "Arquivo bloqueado por segurança"
        )


    categoria = categoria_por_extensao(origem)


    usuario = nome_usuario_seguro(usuario)


    nome_final = nome_arquivo_seguro(
        origem.name
    )


    pasta_destino = (
        destino_base /
        usuario /
        categoria
    )


    pasta_destino.mkdir(
        parents=True,
        exist_ok=True
    )


    destino_final = nome_sem_conflito(
        pasta_destino / nome_final
    )


    shutil.copy2(
        origem,
        destino_final
    )


    return destino_final